function greet(name)
    print("Hello, " .. name .. "!")
end

local user = "Andrew"

greet(user)

function add(a, b)
    return a + b
end

local result = add(5, 7)
print("The result is: " .. result)

for i = 1, 5 do
    print("Counter: " .. i)
end

local number = 10

if number > 5 then
    print("The number is greater than 5")
else
    print("The number is less than or equal to 5")
end